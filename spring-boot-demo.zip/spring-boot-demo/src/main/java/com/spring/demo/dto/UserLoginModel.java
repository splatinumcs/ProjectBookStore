package com.spring.demo.dto;
 

import java.io.Serializable;

import lombok.Data;

@Data
public class UserLoginModel implements Serializable{ 

	private String userName;

	private String password; 
	 
	
	
}
