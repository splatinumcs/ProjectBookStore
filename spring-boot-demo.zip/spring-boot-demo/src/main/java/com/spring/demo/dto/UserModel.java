package com.spring.demo.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import lombok.Data;

@Data
public class UserModel implements Serializable {
	private Long id;

	private String userName;

	private String password; 
	private String role;

	private String fullName;


	private String active;

	private String surname;

	private String dateOfBirth;
	
	private List<Long> books;

	@Override
	public String toString() {
		return "UserModel [id=" + id + ", userName=" + userName + ", password=" + password + ", role=" + role
				+ ", fullName=" + fullName + ", active=" + active + ", surname=" + surname + ", dateOfBirth="
				+ dateOfBirth + "]";
	}
	
	
}
