package com.spring.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.demo.entity.UserInfo;

@Repository
public interface UserRepository extends JpaRepository<UserInfo, Long> {
	 
	
	@Query("SELECT u FROM UserInfo u WHERE userName = ?1")
	List<UserInfo> findUserByUserName(String userName);
	
	@Transactional
	 @Modifying 
	UserInfo save(UserInfo userInfo);
}
