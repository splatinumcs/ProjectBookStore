package com.spring.demo.error;

public class PageNotFoundException extends RuntimeException {

    public PageNotFoundException(Long id) {
        super("Page Not found : " + id);
    }
}
