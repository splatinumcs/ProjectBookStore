package com.spring.demo.entity;

import java.io.Serializable; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="books")
public class Books implements Serializable {
	private static final long serialVersionUID = 1L;
	 
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
    private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="author")
	private String author;
	
	@Column(name="price")	
	private double price;
	
	@Column(name="is_recommended")	
	private String isRecommended;
	
	@Column(name="active")	
	private String active;
	 
	

}
