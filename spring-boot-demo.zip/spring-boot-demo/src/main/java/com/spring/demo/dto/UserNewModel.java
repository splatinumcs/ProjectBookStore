package com.spring.demo.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import lombok.Data;

@Data
public class UserNewModel implements Serializable { 

	private String userName;

	private String password; 

	private String fullName; 

	private String surname;

	private String dateOfBirth;




}
