package com.spring.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.demo.entity.Books; 

@Repository
public interface BookRepository extends JpaRepository<Books, Long> {
	 
	 
	
	@Query("SELECT u FROM Books u WHERE ID = ?1")
	Books searchById(Long id);
	
	@Query("SELECT u FROM Books u WHERE name = ?1")
	List<Books> findBooksByName(String name);
	
	@Query("SELECT u FROM Books u WHERE active = ?1 order by  id ")
	List<Books> findAllBooksByStatus(String active);
	
	@Query("SELECT u FROM Books u WHERE active = ?1 and isRecommended =?2 order by  id ")
	List<Books> findAllBooksByStatusAndisRecommended(String active,String isRecommended);
	
}
