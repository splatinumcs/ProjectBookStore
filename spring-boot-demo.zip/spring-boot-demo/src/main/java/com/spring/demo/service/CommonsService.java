package com.spring.demo.service;

import java.util.Date;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.spring.demo.dto.UserModel;

public interface CommonsService {
   String convertDateToString(Date date);
   Object mapEntityToModel(Object obj) throws JsonProcessingException;
   UserModel mapJsonToObject(String json)throws JsonProcessingException;
   String mapToJson(Object obj)throws JsonProcessingException ;
   String encodePassword(String password) ;
}
