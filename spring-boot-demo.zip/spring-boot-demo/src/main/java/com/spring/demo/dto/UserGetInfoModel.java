package com.spring.demo.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import lombok.Data;

@Data
public class UserGetInfoModel implements Serializable {
	

	private String fullName; 

	private String surname;

	private String dateOfBirth;
	
	private List<Long> books;

 
	
	
}
