package com.spring.boot.demo.test;

 
/*
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import com.spring.demo.service.IUserServiceImpl;
@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class SpringBootDemoApplicationTests {
	
	@Autowired
	private com.spring.demo.controller.UserInfoController UserInfoController;
	
	@Autowired
	private IUserServiceImpl iUserServiceImpl;

	@Test
	public void contextLoads() {
	}

}*/
