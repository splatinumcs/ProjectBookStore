package com.spring.demo.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.demo.dto.UserModel;

@Service
public class CommonsImpl implements CommonsService {

	 
	public String convertDateToString(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy",Locale.UK);
		
		// before  date =1984-04-13 00:00:00.0
		//after  date =13/00/1984
		//Calendar c = Calendar.getInstance(Locale.UK);
		// c.setTime(date);
		if(date !=null) {
			System.out.println(" before  date ="+date);
			String df = sdf.format(date);
			System.out.println(" after  date ="+df);
			return df;
		}
		return null;
	}
	public String encodePassword(String password) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(password);
		return hashedPassword;
	}
	
	public String mapToJson(Object obj) throws JsonProcessingException {
	      ObjectMapper objectMapper = new ObjectMapper();
	      return objectMapper.writeValueAsString(obj);
	   }
	 
	public UserModel mapJsonToObject(String json) throws JsonProcessingException {
	      ObjectMapper objectMapper = new ObjectMapper();
	      try {
			return objectMapper.readValue(json,UserModel.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	   }
	
	public Object mapEntityToModel(Object obj) throws JsonProcessingException {
		Object object = null;
		try {
			object = mapJsonToObject(mapToJson(obj));
			//logger.info(userM.toString());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	      return object;
	   }
	//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS",Locale.US);
}
