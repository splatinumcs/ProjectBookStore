package com.spring.demo.service;

 
import java.util.List;

import com.spring.demo.entity.UserInfo;

public interface IUserService  {

	 

	List<UserInfo> findUserByUserName(String userName);
	
	UserInfo findUserName(String userName);
	
	
	UserInfo save(UserInfo userInfo);
	
	//List<Article>  getAllUserArticles();
}
