package com.spring.demo.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.demo.dto.BookModel;
import com.spring.demo.dto.OrderPriceStatus;
import com.spring.demo.dto.OrderRequest;
import com.spring.demo.dto.UserGetInfoModel;
import com.spring.demo.dto.UserLoginModel;
import com.spring.demo.dto.UserModel;
import com.spring.demo.dto.UserNewModel;
import com.spring.demo.entity.Books;
import com.spring.demo.entity.Orders;
import com.spring.demo.entity.UserInfo;
import com.spring.demo.error.CustomNotFoundException;
import com.spring.demo.error.CustomizedResponseEntityExceptionHandler;
import com.spring.demo.service.*;


@RestController
@RequestMapping("SpringBootDemo")
public class UserInfoController extends CustomizedResponseEntityExceptionHandler {
	//@Autowired
	//private IUserInfoService userInfoService;
	Logger logger = LoggerFactory.getLogger(UserInfoController.class);
	@Autowired
	private CommonsImpl commonsImpl;


	@Autowired
	private IUserServiceImpl iUserServiceImpl;

	@Autowired
	private BookServiceImpl bookServiceImpl;

	@GetMapping("login")
	public ModelAndView login() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("login");
		return mav;
	}	
	/*@GetMapping("secure/article-details")
	public ModelAndView getAllUserArticles() {
		ModelAndView mav = new ModelAndView();
		//mav.addObject("userArticles", iUserServiceImpl.getAllUserArticles());
		mav.setViewName("articles");
		return mav;
	}*/
	@GetMapping("secure/showmenu")
	public ModelAndView getMenuList() {
		ModelAndView mav = new ModelAndView(); 
		mav.setViewName("menu");
		return mav;
	}
	@GetMapping("/loginMenu")
	public ModelAndView getLoginMenu() {
		ModelAndView mav = new ModelAndView(); 
		mav.setViewName("loginDemo");
		return mav;
	}
	@GetMapping("/doCreateUser")
	public ModelAndView doCreateUser() {
		ModelAndView mav = new ModelAndView(); 
		mav.setViewName("createUser");
		return mav;
	}
	@GetMapping("/doOrderUser")
	public ModelAndView getOrderUser() {
		ModelAndView mav = new ModelAndView(); 
		List<Long> orderRequest = new ArrayList<>();
		User userLogin = getUserLogin(); 
		UserInfo userInfo = iUserServiceImpl.findUserName((userLogin!=null?userLogin.getUsername():""));
		if(userInfo !=null  ) {
			try { 
				List<Orders> orderList = bookServiceImpl.searchUserIdByStatusOrder(userInfo.getId(), "Y", "S");

				if(orderList !=null && orderList.size()>0) {


					orderList.stream().forEach(od ->{

						orderRequest.add(od.getId());
					});

				}
				if(orderRequest !=null && orderRequest.size()>0) {
					logger.info("orderRequest == "+orderRequest.size());
				}

				mav.addObject("orderRequest",orderRequest);

			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("getLogin user ");
			}
		}

		mav.setViewName("getOrderUser");
		return mav;
	}

	@GetMapping("error")
	public ModelAndView error() {
		ModelAndView mav = new ModelAndView();
		String errorMessage= "You are not authorized for the requested data.";
		mav.addObject("errorMsg", errorMessage);
		mav.setViewName("error403");
		return mav;
	}	


	@RequestMapping(value = "/loginDemo", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<UserLoginModel> getLogin(UserModel userM) {


		UserLoginModel user = new UserLoginModel();
		User userLogin = getUserLogin();

		if((userM ==null || userM.getUserName() ==null) && userLogin !=null) {
			user.setUserName(userLogin.getUsername());
		}else {
			user.setUserName(userM.getUserName());
		}

		List<UserInfo> list = iUserServiceImpl.findUserByUserName((user!=null?user.getUserName():""));
		if(list !=null && list.size()>0) {
			try {
				UserInfo userInfo = list.get(0);
				user.setUserName(userInfo.getUserName());
				user.setPassword(userInfo.getPassword()); 

			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("getLogin user ");
			}
		}

		return new ResponseEntity<UserLoginModel>(user, HttpStatus.OK);
	}


	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public ResponseEntity<UserGetInfoModel> getUsers() {

		UserGetInfoModel userM = new UserGetInfoModel();
		User userLogin = getUserLogin(); 


		List<UserInfo> list = iUserServiceImpl.findUserByUserName((userLogin!=null?userLogin.getUsername():""));
		if(list !=null && list.size()>0) {
			try {

				UserInfo userInfo = list.get(0);
				if(userInfo !=null ) {
					List<Orders> bookList = bookServiceImpl.searchUserIdByStatus(userInfo.getId(),"Y");
					userM.setFullName(userInfo.getFullName());
					userM.setSurname(userInfo.getSurname());
					userM.setDateOfBirth(userInfo.getDateOfBirth());
					if(bookList !=null && bookList.size()>0) {
						if(userM !=null) {
							List<Long> books = new ArrayList<>();
							bookList.stream().forEach(bk ->{books.add(bk.getBookId());});
							if(books !=null) {
								userM.setBooks(books);
							}
						}
					} 
				}


			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("getLogin user ");
			}
		}

		return new ResponseEntity<UserGetInfoModel>(userM, HttpStatus.OK);
	}




	@RequestMapping(value = "/deleteOrderUser", method = RequestMethod.GET)
	public ResponseEntity<String> getDeleteUsers() {

		User userLogin = getUserLogin(); 
		String  status = "error";
		UserInfo userInfo = iUserServiceImpl.findUserName((userLogin!=null?userLogin.getUsername():""));

		if(userInfo !=null) {
			try { 
				if(userInfo !=null ) {
					int rows = bookServiceImpl.deleteOrdersByUserId(userInfo.getId());
					if(rows >0 ) {
						status = "success";
					}

				}


			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("getLogin user ");
			}
		}

		return new ResponseEntity<String>(status, HttpStatus.OK);
	}

	//@CrossOrigin(origins = "http://localhost:8080")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<UserNewModel> createNewUser(UserNewModel userM) {

		//User userLogin = getUserLogin();
		UserInfo userInfo =  null;
		if(userM !=null && userM.getUserName() !=null) {
			UserInfo userInfoCheck = iUserServiceImpl.findUserName(userM.getUserName());
			if(userInfoCheck == null) {
				userInfo = new UserInfo();
				userInfo.setActive("Y");
				userInfo.setDateOfBirth(userM.getDateOfBirth());
				userInfo.setFullName(userM.getFullName());
				userInfo.setRole("ROLE_USER");
				userInfo.setUserName(userM.getUserName());
				userInfo.setPassword(commonsImpl.encodePassword(userM.getPassword()==null?"password":userM.getPassword()));
				userInfo.setSurname(userM.getSurname());
				userInfo = iUserServiceImpl.save(userInfo);
			}else {
				return new ResponseEntity<UserNewModel>(userM, HttpStatus.EXPECTATION_FAILED);

			}

		}
		userM = new UserNewModel();
		if(userInfo !=null ) {
			try { 
				userM = new UserNewModel();
				userM.setDateOfBirth(userInfo.getDateOfBirth());
				userM.setFullName(userInfo.getFullName()); 
				userM.setUserName(userInfo.getUserName());
				userM.setPassword(userInfo.getPassword());
				userM.setSurname(userInfo.getSurname());
			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("error create New User");
				return new ResponseEntity<UserNewModel>(userM, HttpStatus.EXPECTATION_FAILED);
			}
		}

		return new ResponseEntity<UserNewModel>(userM, HttpStatus.OK);
	}



	@RequestMapping(value = "/users/orders", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<List<OrderPriceStatus>> userOrder(@RequestParam(name = "orderRequest",required = false)  List<String> orderRequest) {

		List<OrderPriceStatus> orderPriceList = new ArrayList<>();

		logger.info("orderRequest ="+orderRequest);
		User userLogin = getUserLogin();

		if((orderRequest !=null && orderRequest.size()>0) && userLogin !=null) {
			//UserInfo userInfo = iUserServiceImpl.findUserName((userLogin!=null?userLogin.getUsername():""));
			orderRequest.stream().forEach(lp -> {
				if(lp !=null) {
					Long pkId = Long.parseLong(lp);
					logger.info("pkId ="+pkId);
					Orders tmp = bookServiceImpl.findByOrderId(pkId);
					OrderPriceStatus temp = new OrderPriceStatus(); 
					temp.setOrderId(tmp.getId());
					Books bk = bookServiceImpl.searchById(tmp.getBookId());
					if(bk !=null) {
						temp.setPrice(bk.getPrice());
					}
					orderPriceList.add(temp);
				}

			}
					);

		}else {

		}


		return new ResponseEntity<List<OrderPriceStatus>>(orderPriceList, HttpStatus.OK);
	}



	//@CrossOrigin(origins = "http://localhost:8080")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getAllBooks", method = RequestMethod.GET)
	public ResponseEntity<List<BookModel>> getAllBooks() {
		List<BookModel> dataList = new  ArrayList<>();
		List<Books> booksList = bookServiceImpl.findAllBooksByStatus("Y");
		ObjectMapper objectMapper = new ObjectMapper();
		if(booksList !=null ) {
			try { 
				booksList.stream().forEach(lp -> {
					BookModel tmp  =new BookModel();
					lp.setIsRecommended(lp.getIsRecommended().equalsIgnoreCase("Y")?"true":"false");

					try {
						tmp = objectMapper.readValue(objectMapper.writeValueAsString(lp),BookModel.class);
						dataList.add(tmp);
					} catch (JsonParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (JsonMappingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


				});
			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("error getAllBooks");
				return new ResponseEntity<List<BookModel>>(dataList, HttpStatus.EXPECTATION_FAILED);
			} 
		}

		return new ResponseEntity<List<BookModel>>(dataList, HttpStatus.OK);
	}
	//@CrossOrigin(origins = "http://localhost:8080")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getAllBooks/recommendation", method = RequestMethod.GET)
	public ResponseEntity<List<BookModel>> getAllBooksRecommendation() {
		List<BookModel> dataList = new  ArrayList<>();
		String recommended = "Y";
		String active = "Y";
		List<Books> booksList = bookServiceImpl.findAllBooksByStatusAndisRecommended(active,recommended);
		ObjectMapper objectMapper = new ObjectMapper();
		if(booksList !=null ) {
			try { 
				booksList.stream().forEach(lp -> {
					BookModel tmp  =new BookModel();
					lp.setIsRecommended(lp.getIsRecommended().equalsIgnoreCase(recommended)?"true":"false");

					try {
						tmp = objectMapper.readValue(objectMapper.writeValueAsString(lp),BookModel.class);
						dataList.add(tmp);
					} catch (JsonParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (JsonMappingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


				});
			} catch (Exception e) { 
				e.printStackTrace();
				logger.error("error getAllBooks");
				return new ResponseEntity<List<BookModel>>(dataList, HttpStatus.EXPECTATION_FAILED);
			} 
		}

		return new ResponseEntity<List<BookModel>>(dataList, HttpStatus.OK);
	}



	private User getUserLogin() {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		User userLogin = (User) auth.getPrincipal();
		return userLogin;
	}

} 