package com.spring.demo.service;


import java.util.List;
 

import com.spring.demo.entity.Books;
import com.spring.demo.entity.Orders; 

public interface BookService  {



	List<Books> findBooksByName(String name);
	
	List<Orders> searchUserIdByStatus(Long userId,String active);
	
	Books searchById(Long id);
	 
	int deleteOrdersByUserId(Long userId);
	
	Orders findByOrderId(Long id);
	
	List<Orders> searchUserIdByStatusOrder(Long userId,String active,String status);
	
	List<Books> findAllBooksByStatus(String active);
	
	List<Books> findAllBooksByStatusAndisRecommended(String active,String isRecommended);
	
}
