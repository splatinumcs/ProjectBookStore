package com.spring.demo.dto;

import java.io.Serializable; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data 
public class BookModel implements Serializable {
	private static final long serialVersionUID = 1L;
	 
	 
    private Long id;
	
	 
	private String name;
	
	 
	private String author;
	
	 
	private double price;
	
	 
	private String isRecommended;
	
	 
	private String active;
	 
	

}
