package test;

import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.demo.controller.UserInfoController;
import com.spring.demo.dto.UserModel;
 
@RunWith(SpringRunner.class)
@WebMvcTest(value = UserTestCrontroller.class, secure = false)
public class UserTestCrontroller {
	Logger logger = LoggerFactory.getLogger(UserTestCrontroller.class);
	
	/*@Autowired
    private TestRestTemplate restTemplate;*/
 
	private UserInfoController userInfoController;
	 
	@Test
	public void getUsers() throws URISyntaxException  {
		try {
			 final String baseUrl = "http://localhost:8080/SpringBootDemo/loginDemo";
			// userInfoController.getLogin(userM)
			 // studentService.addCourse to respond back with mockCourse
			    //Mockito.when(studentService.addCourse(Mockito.anyString(),Mockito.any(Course.class))).thenReturn(mockCourse);
			 UserModel user = new UserModel();
		        user.setUserName("admin");
		        user.setPassword("password");
		        logger.info(mapToJson(user));
			    // Send course as body to /students/Student1/courses
			   /* RequestBuilder requestBuilder = MockMvcRequestBuilders
			            .post("/SpringBootDemo/loginDemo")
			            .accept(MediaType.APPLICATION_JSON)
			            .content(mapToJson(user))
			            .contentType(MediaType.APPLICATION_JSON);

			    MvcResult result = mockMvc.perform(requestBuilder).andReturn();

			    MockHttpServletResponse response = result.getResponse();

			    assertEquals(HttpStatus.ACCEPTED.value(), response.getStatus());

			    assertEquals("http://localhost/students/Student1/courses/1",response.getHeader(HttpHeaders.LOCATION));*/
		       /* URI uri = new URI(baseUrl);
		        UserModel user = new UserModel();
		        user.setUserName("admin");
		        user.setPassword("password");
		         
		        HttpHeaders headers = new HttpHeaders();
		        headers.set("X-COM-PERSIST", "true");      
		 
		        HttpEntity<UserModel> request = new HttpEntity<>(user, headers);
		         
		        ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
		         
		        //Verify request succeed
		        Assert.assertEquals(201, result.getStatusCodeValue()); */
	    } catch (Exception e) {
	        logger.error("Junit :: Exception :: getAllTransactionList_Test() ::  ", e);
	    }
	}
	 protected String mapToJson(Object obj) throws JsonProcessingException {
	      ObjectMapper objectMapper = new ObjectMapper();
	      return objectMapper.writeValueAsString(obj);
	   }
}
