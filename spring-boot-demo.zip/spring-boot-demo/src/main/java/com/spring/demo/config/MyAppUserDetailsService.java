package com.spring.demo.config;
 
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException; 
import com.spring.demo.dto.UserModel;
import com.spring.demo.entity.UserInfo;
import com.spring.demo.service.CommonsImpl; 
import com.spring.demo.service.IUserServiceImpl;

 
 
@Service
public class MyAppUserDetailsService implements UserDetailsService {
	
	Logger logger = LoggerFactory.getLogger(MyAppUserDetailsService.class);
	
	@Autowired
	private IUserServiceImpl iUserServiceImpl;
	
	//@Autowired
	//private CommonsImpl commonsImpl;
	
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException {
		
		
		System.out.println(" userName = "+userName);
		List<UserInfo> list =iUserServiceImpl.findUserByUserName(userName);
		UserInfo activeUserInfo = list!=null&&list.size()>0?list.get(0):null;
		
		
		/*try {
			UserModel userM = (UserModel) commonsImpl.mapEntityToModel(activeUserInfo);
			logger.info(userM.toString());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		GrantedAuthority authority = new SimpleGrantedAuthority(activeUserInfo.getRole());
		UserDetails userDetails = (UserDetails)new User(activeUserInfo.getUserName(),
				activeUserInfo.getPassword(), Arrays.asList(authority));
		return userDetails;
	}
	
	
	 
}

