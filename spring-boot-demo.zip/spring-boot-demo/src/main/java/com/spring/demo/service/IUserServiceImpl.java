package com.spring.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

import com.spring.demo.entity.UserInfo;
import com.spring.demo.repository.UserRepository;



@Service
public class IUserServiceImpl implements  IUserService {

	@Autowired
	private UserRepository userRepository;

	/*@Autowired
	private ArticleRepository articleRepository;*/




	@Transactional
	public List<UserInfo> findUserByUserName(String userName) {
		// TODO Auto-generated method stub
		return userRepository.findUserByUserName(userName);
	}

	@Transactional
	@Modifying 
	public UserInfo save(UserInfo userInfo) {
		 
		return userRepository.save(userInfo);
	}


	/*@Transactional
	public List<Article>  getAllUserArticles() {
		// TODO Auto-generated method stub
		return articleRepository.getAllUserArticles();
	}*/

	@Transactional
	public UserInfo findUserName(String userName) {
		UserInfo userInfo = null;
		List<UserInfo> list = findUserByUserName(userName);
		if(list !=null && list.size()>0) {
			userInfo = list.get(0);
		}
		return userInfo;
	}







}
