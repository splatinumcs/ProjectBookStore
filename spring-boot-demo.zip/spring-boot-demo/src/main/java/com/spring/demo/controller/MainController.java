package com.spring.demo.controller;
 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class MainController {

	  @GetMapping("/")
    public ModelAndView root() {
		  ModelAndView mav = new ModelAndView();
		    mav.setViewName("home");
        return mav;
    }
	  @GetMapping("logout")
	  public ModelAndView logoutPag(HttpServletRequest request, HttpServletResponse response) {
		  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			if (auth != null){    
				new SecurityContextLogoutHandler().logout(request, response, auth);
			}
		    ModelAndView mav = new ModelAndView();
		    mav.setViewName("home");
		    return mav;
	  }
}
