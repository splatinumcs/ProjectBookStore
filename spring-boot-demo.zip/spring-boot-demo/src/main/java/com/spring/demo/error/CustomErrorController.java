package com.spring.demo.error;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomErrorController implements ErrorController {

  @RequestMapping("/error")
  public ModelAndView handleError(HttpServletRequest request) {
	  Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
      Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
      
      System.out.println(new Date()+"statusCode ="+statusCode);
      //System.out.println("exception ="+exception.getLocalizedMessage());
	    ModelAndView mav = new ModelAndView();
	    if(statusCode == 404) {
	    	mav.setViewName("error404");
	    }
	    else if(statusCode == 404) {
	    	mav.setViewName("error400");
	    }
	    else {
	    	mav.setViewName("error403");
	    }
	    return mav;
}
  /*@ResponseBody
  public String handleError(HttpServletRequest request) {
      Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
      Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
      return String.format("<html xmlns:th=\"http://www.thymeleaf.org\"> <body><h2>Page not found.</h2>"+
    		  "<h2>Please click back to Login <a th:href=\"@{/SpringBootDemo/login}\">Login</a></h2> "+
      		 "<div>Status code: <b>%s</b></div>"+
                    "<div>Exception Message: <b>%s</b></div><body></html>",
              statusCode, exception==null? "N/A": exception.getMessage());
  }*/

  @Override
  public String getErrorPath() {
      return "/error";
  }
}