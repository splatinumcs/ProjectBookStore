package com.spring.demo.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.demo.entity.Books;
import com.spring.demo.entity.Orders; 

@Repository
public interface OrderRepository extends JpaRepository<Orders, Long> {
	 
	
	@Query("SELECT u FROM Orders u WHERE userId = ?1")
	List<Orders> findByUserId(String userId);
	
	@Query("SELECT u FROM Orders u WHERE bookId = ?1")
	List<Orders> findByBookId(String bookId);
	
	@Query("SELECT u FROM Orders u  order by  userId ")
	List<Orders> findAllStatus(String bookId);
	
	@Query("SELECT u FROM Orders u WHERE active = ?1 order by  userId ")
	List<Orders> findAllByStatus(String active);
	
	@Query("SELECT u FROM Orders u WHERE  userId = ?1 and active = ?2 order by  bookId ")
	List<Orders> searchUserIdByStatus(Long userId,String active);
	
	
	@Query("SELECT u FROM Orders u WHERE  userId = ?1 and active = ?2 and status = ?3 order by  bookId ")
	List<Orders> searchUserIdByStatusOrder(Long userId,String active,String status);
	
	@Query("SELECT u FROM Orders u WHERE id = ?1 order by  id ")
	Orders findByOrderId(Long id);
 
	@Transactional
	 @Modifying 
	@Query("delete FROM Orders u WHERE  u.userId = ?1  ")
	int deleteOrdersByUserId(Long userId);
	
}
