package com.spring.demo.service;
 
import java.util.List; 

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
 
import com.spring.demo.entity.Books;
import com.spring.demo.entity.Orders; 
import com.spring.demo.repository.*; 

 

@Service
public class BookServiceImpl implements  BookService {

    @Autowired
    private BookRepository bookRepository;
 
    @Autowired
    private OrderRepository orderRepository;

	 
	 
	@Transactional
	public Books searchById(Long id) {
		// TODO Auto-generated method stub
		return bookRepository.searchById(id);
	}
	@Transactional
	public List<Books> findBooksByName(String  name) {
		// TODO Auto-generated method stub
		return bookRepository.findBooksByName(name);
	}
	
	 
	@Transactional
	public Books save(Books books) {
		// TODO Auto-generated method stub
		return bookRepository.save(books);
	}
 
	@Transactional
	public List<Orders> searchUserIdByStatus(Long userId,String  active) {
		// TODO Auto-generated method stub
		return orderRepository.searchUserIdByStatus(userId, active);
	}
	@Transactional 
	@Modifying
	public int deleteOrdersByUserId(Long userId) {
		// TODO Auto-generated method stub
		return orderRepository.deleteOrdersByUserId(userId);
	}
	@Transactional 
	public List<Orders> searchUserIdByStatusOrder(Long userId, String active, String status) {
		// TODO Auto-generated method stub
		return orderRepository.searchUserIdByStatusOrder(userId, active, status);
	}
	@Transactional 
	public Orders findByOrderId(Long id) {
		// TODO Auto-generated method stub
		return orderRepository.findByOrderId(id);
	}
	
	
	@Transactional 
	public List<Books> findAllBooksByStatus(String active) {
	 
		return bookRepository.findAllBooksByStatus(active);
	}
	@Transactional 
	public List<Books> findAllBooksByStatusAndisRecommended(String active, String isRecommended) {
		// TODO Auto-generated method stub
		return bookRepository.findAllBooksByStatusAndisRecommended(active, isRecommended);
	}
	
 
  

    

     
}
