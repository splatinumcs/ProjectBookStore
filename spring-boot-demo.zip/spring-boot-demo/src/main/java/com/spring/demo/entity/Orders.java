package com.spring.demo.entity;

import java.io.Serializable; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="orders")
public class Orders implements Serializable {
	private static final long serialVersionUID = 1L;
	 
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
    private Long id;
	
	@Column(name="book_id")
	private Long bookId;
	
	@Column(name="user_id")
	private Long userId;
 
	
	@Column(name="remakrs")	
	private String remakrs;
	
	@Column(name="active")	
	private String active;
	
	@Column(name="status")	
	private String status;
	 
	

}
